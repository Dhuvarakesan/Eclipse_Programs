package practice;

public class SubString {

	public static void main(String[] args) {
		String in="dhuvarakesan";
		String out=in.substring(1, 2);
		System.out.println(out);

	}

}
