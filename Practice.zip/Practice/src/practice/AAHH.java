package practice;

public abstract	 class AAHH {
	void disp() {
		System.out.println("hello");
	}
	public abstract void  disp1();

}
