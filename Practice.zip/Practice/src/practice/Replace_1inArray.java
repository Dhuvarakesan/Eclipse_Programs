package practice;

public class Replace_1inArray {

}
