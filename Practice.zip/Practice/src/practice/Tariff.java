/*
 * package practice; import java.util.Scanner; public class Tariff {
 * 
 * public static void main(String[] args) { Scanner sc=new Scanner(System.in);
 * System.out.println("ENTER THE NUMBER OF UNITS: "); int no_units=sc.nextInt();
 * double a=0; double b=(n-100)*1.5; double c=n-100; //double d=(c-200)*2;
 * double e=(c-100)*3;
 * 
 * if(n>100&&n<=200){ System.out.println("FIXED CHARGE: 20");
 * System.out.print("TOTAL BILL AMOUNT: "); System.out.print(a+b+20); } else
 * if(n>100&&n<=500){ double f=((c-100)*3)+(100*2);
 * System.out.println("FIXED CHARGE: 30");
 * System.out.print("TOTAL BILL AMOUNT: "); System.out.print(a+f+30); } else
 * if(n>500){ double g=(n-500)*6.6; double h=g+(300*4.6)+(100*3.5);
 * System.out.println("FIXED CHARGE: 50");
 * System.out.print("TOTAL BILL AMOUNT: "); System.out.print(a+h+50); } else{
 * System.out.println("NO FIXED CHARGE: 0.0");
 * System.out.println("TOTAL BILL AMOUNT: "+a); } }
 * 
 * }
 */