package practice;

public class Try {

	public static void main(String[] args) {
		System.out.println("dhuvara\nhello");
		int a=4;
		int b=11;
		int c=-10;
	if(a>10||b>10&&c>10) 
	if((a>10||b>10)&&(c>10)) {
		
	}

	}

}
