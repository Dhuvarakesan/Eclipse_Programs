package practice;

public class HHAA extends AAHH {
	public void disp1() {
		System.out.println("DHUVARA");
	}
	void disp() {
		System.out.println("kesan");
	}

	public static void main(String[] args) {
		HHAA s=new HHAA();
		s.disp();
		s.disp1();
		

	}

}
